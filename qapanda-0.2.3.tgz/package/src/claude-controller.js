const { writeText, randomId } = require('./utils');
const { spawnStreamingProcess } = require('./process-utils');
const { parseJsonLine, extractTextFromClaudeContent } = require('./events');
const { buildControllerPrompt } = require('./prompts');
const { validateControllerDecision, controllerDecisionSchema } = require('./schema');

function buildClaudeControllerArgs(manifest, loop) {
  const args = [
    '-p',
    '--output-format',
    'stream-json',
    '--verbose',
    '--dangerously-skip-permissions',
    '--setting-sources', 'local',
    '--strict-mcp-config',
  ];

  if (manifest.controller.sessionId) {
    args.push('--resume', manifest.controller.sessionId);
  } else {
    // Generate a proper UUID for the initial session (Claude CLI requires valid UUIDs)
    if (!manifest.controller.claudeSessionId) {
      manifest.controller.claudeSessionId = randomId();
    }
    args.push('--session-id', manifest.controller.claudeSessionId);
  }

  if (manifest.controller.model) {
    args.push('--model', manifest.controller.model);
  }

  // Enforce structured JSON output — works with both --session-id and --resume in -p mode
  args.push('--json-schema', JSON.stringify(controllerDecisionSchema));

  // Pass controller MCP servers
  const controllerMcp = manifest.controllerMcpServers || manifest.mcpServers || {};
  if (Object.keys(controllerMcp).length > 0) {
    const mcpConfig = { mcpServers: {} };
    for (const [name, server] of Object.entries(controllerMcp)) {
      if (!server) continue;
      if (server.url) {
        mcpConfig.mcpServers[name] = { type: 'http', url: server.url };
        continue;
      }
      if (!server.command) continue;
      mcpConfig.mcpServers[name] = { type: 'stdio', command: server.command, args: server.args || [] };
      if (server.env) mcpConfig.mcpServers[name].env = server.env;
    }
    if (Object.keys(mcpConfig.mcpServers).length > 0) {
      let mcpJson = JSON.stringify(mcpConfig);
      if (manifest.extensionDir) {
        mcpJson = mcpJson.replace(/\{EXTENSION_DIR\}/g, manifest.extensionDir.replace(/\\/g, '/'));
      }
      if (manifest.repoRoot) {
        mcpJson = mcpJson.replace(/\{REPO_ROOT\}/g, manifest.repoRoot.replace(/\\/g, '/'));
      }
      args.push('--mcp-config', mcpJson);
    }
    // Disable built-in Bash when detached-command is available
    if (controllerMcp['detached-command']) {
      args.push('--disallowedTools', 'Bash');
    }
  }

  return args;
}

async function runClaudeControllerTurn({ manifest, request, loop, renderer, emitEvent, abortSignal }) {
  const prompt = buildControllerPrompt(manifest, request);
  await writeText(loop.controller.promptFile, `${prompt}\n`);

  const args = buildClaudeControllerArgs(manifest, loop);
  let discoveredSessionId = manifest.controller.sessionId;

  let accumulatedText = '';
  let lastAssistantMessage = '';
  let structuredOutput = null;
  let sawTextDelta = false;

  // Strip ELECTRON_RUN_AS_NODE to prevent Claude Code from running as plain Node
  const { ELECTRON_RUN_AS_NODE: _, ...cleanEnv } = process.env;

  const result = await spawnStreamingProcess({
    command: manifest.controller.bin,
    args,
    cwd: manifest.repoRoot,
    env: cleanEnv,
    stdinText: prompt,
    abortSignal,
    onStdoutLine: (line) => {
      const raw = parseJsonLine(line);
      Promise.resolve(emitEvent({
        ts: new Date().toISOString(),
        source: 'controller-json',
        requestId: request.id,
        loopIndex: loop.index,
        rawLine: line,
        parsed: raw,
      })).catch(() => {});

      if (!raw) {
        renderer.controller(`(unparsed claude-controller line) ${line}`);
        return;
      }

      // Discover session ID from system event
      if (raw.session_id) {
        discoveredSessionId = raw.session_id;
      }

      // Accumulate text from streaming deltas (for rendering only)
      if (raw.type === 'stream_event') {
        const event = raw.event || {};
        if (event.type === 'content_block_delta' && event.delta?.type === 'text_delta') {
          if (!sawTextDelta && event.delta.text) {
            event.delta.text = event.delta.text.replace(/^\n+/, '');
          }
          accumulatedText += event.delta.text || '';
          sawTextDelta = true;
        }
      }

      if (raw.type === 'assistant_message' || raw.type === 'assistant') {
        const text = extractTextFromClaudeContent(raw.message?.content || raw.content);
        if (text) lastAssistantMessage = text;
      }

      // Capture structured_output from the result event (set by --json-schema)
      if (raw.type === 'result_message' || raw.type === 'result') {
        if (raw.structured_output && typeof raw.structured_output === 'object') {
          structuredOutput = raw.structured_output;
        }
      }

      // Render controller events — use controllerEvent for streaming events,
      // skip assistant/result if we have text deltas (same logic as claude.js worker)
      if ((raw.type === 'assistant_message' || raw.type === 'assistant') && sawTextDelta) {
        return;
      }
      if ((raw.type === 'result_message' || raw.type === 'result') && sawTextDelta) {
        renderer.flushStream();
        return;
      }

      // Render as controller activity (not worker)
      renderer.claudeControllerEvent(raw);
    },
    onStderrLine: (line) => {
      Promise.resolve(emitEvent({
        ts: new Date().toISOString(),
        source: 'controller-stderr',
        requestId: request.id,
        loopIndex: loop.index,
        text: line,
      })).catch(() => {});
      if (!manifest.settings.quiet) {
        renderer.controller(line);
      }
    },
  });

  loop.controller.exitCode = result.code;
  loop.controller.sessionId = discoveredSessionId;
  manifest.controller.sessionId = discoveredSessionId;

  if (result.aborted) {
    throw new Error('Claude controller process was interrupted.');
  }

  if (result.code !== 0) {
    throw new Error(`Claude controller exited with code ${result.code}. See ${loop.controller.stderrFile}`);
  }

  // Use structured_output from --json-schema (guaranteed valid JSON on resume and fresh sessions)
  if (!structuredOutput) {
    throw new Error('Claude controller did not return structured JSON output.');
  }
  const decision = validateControllerDecision(structuredOutput);
  loop.controller.decision = decision;
  request.latestControllerDecision = decision;

  return {
    prompt,
    decision,
    sessionId: discoveredSessionId,
  };
}

module.exports = {
  buildClaudeControllerArgs,
  runClaudeControllerTurn,
};
